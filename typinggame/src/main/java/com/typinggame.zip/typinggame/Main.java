package com.typinggame;

import javax.swing.SwingUtilities;

import com.typinggame.GUI.TypingGameFrame;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TypingGameFrame frame = new TypingGameFrame();
            frame.setVisible(true);
            frame.requestTypingFocus();
        });
    }
}